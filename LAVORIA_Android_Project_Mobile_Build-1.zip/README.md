# L'AVORIA Android project

This is a native Android Studio starter project (Kotlin + Jetpack Compose), not a compiled APK.
It includes an initial Arabic UI for home, services, shop cart counter, bookings placeholder, and admin-login placeholder.

## Build an APK from an Android phone using GitHub Actions
1. Create a GitHub account or sign in at https://github.com.
2. Create a new repository named `lavoria-android`.
3. Extract this ZIP on your phone.
4. Upload the extracted project files and folders to the repository root, preserving `.github/workflows/android.yml`.
5. Open the repository's Actions tab and run `Build LAVORIA APK` (or wait for the automatic build after pushing).
6. When the run succeeds, open it and download the `LAVORIA-debug-APK` artifact.
7. Extract the downloaded artifact ZIP and install `app-debug.apk`.

The GitHub workflow uses JDK 17 and Gradle 8.9 to build `assembleDebug`.

## Important limitations
- This is a starter app, not a finished production system.
- No backend/database, real authentication, order submission, payment processing, receipt upload, or push notifications.
- Shop prices are intentionally not invented.
- The cart counter is in-memory only.
- Admin login is a visual placeholder and does not authenticate.
- Customer photography/video is not collected.
- The debug APK is for testing; a production Play Store release needs signing and further development.

Application ID: com.lavoria.app
