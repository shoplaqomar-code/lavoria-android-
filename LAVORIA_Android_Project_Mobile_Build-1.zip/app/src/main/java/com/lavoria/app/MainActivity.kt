package com.lavoria.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF111111)
private val Gold = Color(0xFFC5A15A)
private val Ivory = Color(0xFFF7F2E8)
private val Muted = Color(0xFF6F685D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LavoriaApp() }
    }
}

@Composable
fun LavoriaApp() {
    var page by remember { mutableStateOf("الرئيسية") }
    var cartCount by remember { mutableIntStateOf(0) }
    var showAdmin by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(
        primary = Gold, onPrimary = Black, background = Ivory, surface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Ivory)) {
            Column(
                Modifier.fillMaxWidth().background(Black).padding(horizontal = 22.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("L'AVORIA", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("BEAUTY • BRIDAL • ELEGANCE", color = Ivory, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            if (showAdmin) {
                AdminScreen(onBack = { showAdmin = false })
            } else {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("الرئيسية", "الخدمات", "المتجر", "حجوزاتي").forEach { tab ->
                        TextButton(onClick = { page = tab }) {
                            Text(tab, color = if (page == tab) Gold else Black, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                when (page) {
                    "الرئيسية" -> HomeScreen(onServices = { page = "الخدمات" }, onShop = { page = "المتجر" }, onAdmin = { showAdmin = true })
                    "الخدمات" -> ServicesScreen()
                    "المتجر" -> ShopScreen(cartCount, onAdd = { cartCount++ })
                    else -> BookingsScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onServices: () -> Unit, onShop: () -> Unit, onAdmin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("أناقتكِ تبدأ من هنا", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Black)
        Text("كل تفاصيل جمالك ويومك المميز في مكان واحد.", color = Muted, fontSize = 15.sp)
        FeatureCard("خدمات التجميل والعناية", "تصفيف شعر، مكياج، أظافر وعناية بالبشرة", onServices)
        FeatureCard("متجر لافوريا", "تصفحي المنتجات وأضيفيها إلى سلتك", onShop)
        FeatureCard("لوحة الإدارة", "دخول مخصص لمدير لافوريا", onAdmin)
        Spacer(Modifier.weight(1f))
        Text("نسخة أولية للتصميم — لا تحفظ الطلبات أو الحجوزات بعد", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Black, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun ServicesScreen() {
    val services = listOf("تصفيف الشعر", "المكياج", "الأظافر", "العناية بالبشرة", "تأجير فساتين الزفاف", "التصوير والإنتاج")
    LazyColumn(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("خدماتنا", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Black) }
        items(services) { FeatureCard(it, "يمكن طلب موعد — تأكيد الحجز يتم من الصالون", {}) }
    }
}

@Composable
fun ShopScreen(count: Int, onAdd: () -> Unit) {
    val products = listOf("مجموعة عناية بالبشرة", "أحمر شفاه", "زيت شعر", "عطر نسائي")
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("متجر لافوريا", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Black)
        Text("السلة: $count منتجات", color = Gold, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(products) { product ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(product, color = Black, fontWeight = FontWeight.SemiBold)
                            Text("السعر يحدد من إدارة الصالون", color = Muted, fontSize = 12.sp)
                        }
                        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                            Text("أضيفي للسلة", color = Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BookingsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("حجوزاتي", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Black)
        Text("طلبات الحجز ستظهر هنا بعد ربط التطبيق بقاعدة البيانات.", color = Muted)
        Text("تأكيد المواعيد يتم بالتواصل مع الصالون.", color = Muted)
    }
}

@Composable
fun AdminScreen(onBack: () -> Unit) {
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("رجوع", color = Gold) }
        Text("مدير لافوريا", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Black)
        OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور") }, modifier = Modifier.fillMaxWidth())
        Text("واجهة دخول شكلية حالياً؛ لا يوجد تحقق أو حساب حقيقي بعد.", color = Muted, fontSize = 12.sp)
        Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
            Text("تسجيل الدخول", color = Black)
        }
    }
}
